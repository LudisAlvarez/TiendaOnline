<template>
  <div>
    <v-toolbar
      image="https://external-preview.redd.it/72pnxbZx3-jKvfl8L6XGcpNWTE0aLebLcJzvQ0sXtvo.png?width=1080&crop=smart&auto=webp&s=855ad9e8575c5ca4921852459b7ff808a45d3618"
      dark
      height="150"
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title><h1 style="color: White">ANIME SWEATERS</h1></v-toolbar-title>

      <v-spacer></v-spacer>

      <carrito
        class="mr-5"
        :productos="productos"
        :cantidadProductos="cantidadProductos"
        @eliminarProducto="(index) => $emit('eliminarProducto', index)">
      </carrito>
    </v-toolbar>
  </div>
</template>

<script>
import carrito from '~/components/carrito.vue'

export default {
  components: { carrito },
  props: {
    productos: Array,
    cantidadProductos: Number
  }
}
</script>
