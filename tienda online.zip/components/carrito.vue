<template>
  <div>
    <v-badge color="error" :content="productos.length">
      <v-btn icon @click="toggleModal">
        <v-icon>mdi-cart</v-icon>
      </v-btn>
    </v-badge>

    <v-dialog v-model="mostrarModal" max-width="400px" persistent>
      <v-card>
        <v-card-title>Carrito de Compras</v-card-title>
        <v-card-text>
          <div v-if="productos.length">
            <div v-for="(producto, index) in productos" :key="index" class="producto">
              <img :src="producto.imagen" alt="producto imagen" width="50" />
              <div>
                <p>{{ producto.titulo }}</p>
                <p>${{ producto.precio }}</p>
              </div>
              <v-btn icon color="error" @click="eliminarProducto(index)">
                <v-icon>mdi-delete</v-icon>
              </v-btn>
            </div>
          </div>
          <p v-else>El carrito está vacío.</p>
        </v-card-text>
        <v-card-actions>
          <v-btn color="primary" @click="mostrarModal = false">Cerrar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <factura 
      :show="show"
      @cerrar="cerrar"
      :compras="productos"
      @eliminar="eliminarProducto"
    />
  </div>
</template>

<script>
export default {
  props: {
    productos: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      mostrarModal: false,
      show: false 
    };
  },
  methods: {
    
    toggleModal() {
      this.mostrarModal = !this.mostrarModal;
    },

    eliminarProducto(index) {
      this.productos.splice(index, 1);
    },

    detalle() {
      this.show = true;
    },

    cerrar() {
      this.show = false;
    }
  }
};
</script>

<style scoped>

.contador {
  position: absolute;
  top: -10px;
  right: -10px;
  background-color: red; 
  color: white; 
  border-radius: 50%;
  padding: 2px 6px;
  font-size: 12px;
  font-weight: bold;
}


.v-icon {
  color: white; 
}

.producto {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}
</style>

