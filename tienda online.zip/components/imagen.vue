<template>
    <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
      <h1>{{ titulo }}</h1>
      <img 
        :style="{ width: ancho + 'px', height: alto + 'px', display: 'block', margin: '0 auto', objectFit: 'contain' }" 
        :src="img" 
        alt="Imagen centrada"
      >
    </div>
  </template>
  
  <script>
  export default {
    props: {
      titulo: String,
      img: String,
      ancho: Number,
      alto: Number
    }
  }
  </script>
  