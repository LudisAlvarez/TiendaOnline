
<template>
  <v-card
    class="mx-auto"
    max-width="344"
  >
  <v-img
      :src="info.imagen"
      alt="Imagen del producto"
      class="centrar-imagen"
      max-height="200"
    />
    <v-card-title>
      {{ info.titulo}}
    </v-card-title>

    <v-card-subtitle>
      {{ info.descripcion}}
    </v-card-subtitle>

    <v-card-actions>
      <v-btn
        @click="compra()"
        color="orange-lighten-2"
        :text="info.precio"
      ></v-btn>

      <v-spacer></v-spacer>

     
    </v-card-actions>

  </v-card>
</template>
<script>
export default {
  props: {
  info: {
      type: Object,
      default: 0
  },
},
methods: {
  compra(){
    this.$emit('compra', this.info)
  }
},
}
</script>

<style scoped>
.centrar-imagen {
  display: flex;
  justify-content: center;
  align-items: center;
  object-fit: cover; /* Para asegurar que la imagen se ajuste bien */
}
</style>