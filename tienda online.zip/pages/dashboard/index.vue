<template>
    <div>
    <NuxtLayout>
        
    </NuxtLayout>

      <NuxtLink to="/about">About</NuxtLink>
            <NuxtPage />
<NuxtPage />
    </div>
    
  </template>