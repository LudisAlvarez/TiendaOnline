<template>
    <div>
      <cabezote
      :productos="comprasrealizadas"
      :cantidadProductos="comprasrealizadas.length"
      @eliminarProducto="eliminarProducto">
    </cabezote>

        <manager
         :productos="productos"
         @compra="compra">
        </manager>
       
        <footer class="vivi" > <center> ANIME SWEATERS
      </center> </footer>
    </div>
</template>
<script>
import cabezote from '~/components/cabezote.vue'
export default {
  components: { cabezote },
    data() {
        return {
         
          comprasrealizadas : [],
          productos : [
            {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_737221-MCO70733547728_072023-F.webp',
                precio :  95.992,
                titulo : 'Chaqueta De Béisbol Hunter X Hunter Kawaii Killua',
                descripcion : 'Color:Rosa chicle'
            },
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_991994-CBT79591819280_102024-F.webp',
                precio : 135.135,
                titulo : 'Commuter Daily Leisure Y2k Japanese Anime Sweater',
                descripcion : 'Color:Blanco',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_613470-CBT79596227238_102024-F.webp',
                precio : 145.207,
                titulo : 'Suéter Holgado De Jacquard Con Dibujos Animados De Personali',
                descripcion : 'Color:Gris',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_922007-CBT79171622271_092024-F.webp',
                precio : 144.851,
                titulo : 'Polera Con Diseño De Anime King Of The Seas 2024',
                descripcion : 'Color:Negro',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_675343-CBT48607846079_122021-F.webp',
                precio : 109.062,
                titulo : 'Sudadera Con Capucha Kaisen Hip Hop Anime Pullovers Sudadera',
                descripcion : 'Color:Negro',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_655318-CBT80070782082_102024-F.webp',
                precio : 191.649,
                titulo : 'Suéter De Mujer De Gran Tamaño Anime Aesthetic Kawaii',
                descripcion : 'Color:Negro',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_751640-CBT80147146444_112024-F.webp',
                precio : 176.540,
                titulo : 'Chamarra Denim Negro Anime Naruto Uchiha Logo Akatsuki',
                descripcion : 'Color:Negro',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_747907-CBT80147148384_112024-F.webp',
                precio : 133.486,
                titulo : 'Sudadera Con Capucha Unisex Dr.stone Cosplay Anime Sudader',
                descripcion : 'Color:Beige',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_859846-CBT76385441785_052024-F.webp',
                precio : 348.845,
                titulo : 'Anime Draken Draken Cosplay Sweater Chaqueta De Punto',
                descripcion : 'Color:Fix',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_683219-CBT47884459343_102021-F.webp',
                precio : 292.242,
                titulo : 'Anime Death Note Misa Amane Imitación Cuero Sexy Tubo Tops',
                descripcion : 'Color:Sweater',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_728080-CBT80071256390_102024-F.webp',
                precio : 153.408 ,
                titulo : 'Chamarra Con Botones De Béisbol De Anime De Dragon Ball Goku',
                descripcion : 'Color:Negro',

             } ,
             {
                imagen : 'https://http2.mlstatic.com/D_NQ_NP_2X_865825-CBT79561542522_102024-F.webp',
                precio : 159.826,
                titulo : 'Anime Black Butler Sudaderas De Manga Larga Suéter Fino',
                descripcion : 'Color:Negro',

             } ,

          ]
            

                               
           
        }
      },
  methods: {
    compra(data) {
      this.comprasrealizadas.push(data)
    },
    eliminarProducto(index) {
      this.comprasrealizadas.splice(index, 1)
    }
  }
}
</script>

<style>
.vivi {
   padding:30px ;
   background-color: #333;
   color:#000
}
</style>
